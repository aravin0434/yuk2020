const express = require('express');
const mongoose = require('mongoose');
const User = require('../models/User');
const Event = require('../models/event');
const Workshop = require('../models/workshop');
const Paper = require('../models/paperPresentation');
const Team = require("../models/team");
const crypto = require("crypto");
const router = express.Router();
const path = require('path');
const waterfall = require('async-waterfall');
const nodemailer = require('nodemailer');
const { google } = require('googleapis');
const OAuth2 = google.auth.OAuth2;
const {iLog, iNLog} = require('../config/auth');

// automate email

const oauth2Client = new OAuth2(
    "293583068886-3lg508q3uldbe5kbjepui7dn48fjoq3i.apps.googleusercontent.com",
    "YjwJ_8ZGAmhRY3fSDSkZ3X0c",
    "https://developers.google.com/oauthplayground"
);


oauth2Client.setCredentials({
    refresh_token: "1//04XX8u0OIjZRlCgYIARAAGAQSNwF-L9IrupXNGSplIZUaVq8E1jjpiWOzqrtCfMmDiTb7MOT-G_p8hLPdvRPjD288hVevZS9o6jc"
});
const accessToken = oauth2Client.getAccessToken();

const smtpTransport = nodemailer.createTransport({
    service: "gmail",
    auth: {
         type: "OAuth2",
         user: "yukta@psgitech.ac.in", 
         clientId: "293583068886-3lg508q3uldbe5kbjepui7dn48fjoq3i.apps.googleusercontent.com",
         clientSecret: "YjwJ_8ZGAmhRY3fSDSkZ3X0c",
         refreshToken: "1//04XX8u0OIjZRlCgYIARAAGAQSNwF-L9IrupXNGSplIZUaVq8E1jjpiWOzqrtCfMmDiTb7MOT-G_p8hLPdvRPjD288hVevZS9o6jc",
         accessToken: accessToken
    }
});


//add events page

router.get('/add_event', (req, res) => {
    res.render('add_event');
});

router.get('/add_workshop', (req, res) => {
    res.render('add_workshop');
});

router.get('/add_paper', (req, res) => {
    res.render('add_paper');
});

//dept redirect

router.post('/close', (req, res) =>{
    res.redirect(req.body.url);
});

//default page
router.get('/',(req, res) =>{
    res.render('home');
});

router.get('/event', iLog,(req, res) => {
    res.render('event dummy');
});

router.get('/non_technical',(req, res) => {
    if(req.isAuthenticated())
        res.render('nontechnical', {iLog: true});
    else
        res.render('nontechnical', {iLog: false});
});


router.get('/ece',(req, res) =>{
    if(req.isAuthenticated())
        res.render('ece_events',{iLog: true});
    else
        res.render('ece_events',{iLog: false});
});

router.get('/cse',(req, res) =>{
    if(req.isAuthenticated())
        res.render('cse_events',{iLog: true});
    else
        res.render('cse_events',{iLog: false});
});

router.get('/civil',(req, res) =>{
    if(req.isAuthenticated())
        res.render('civil_events',{iLog: true});
    else
        res.render('civil_events',{iLog: false});
});

router.get('/eee',(req, res) =>{
    if(req.isAuthenticated())
        res.render('eee_events',{iLog: true});
    else
        res.render('eee_events',{iLog: false});
});

router.get('/mech',(req, res) =>{
    if(req.isAuthenticated())
        res.render('mech_events',{iLog: true});
    else
        res.render('mech_events',{iLog: false});
});

router.get('/about',(req, res) =>{
    if(req.isAuthenticated())
        res.render('about',{iLog: true});
    else
        res.render('about',{iLog: false});
});

router.get('/proshow',(req, res) =>{
    if(req.isAuthenticated())
        res.render('proshow',{iLog: true});
    else
        res.render('proshow',{iLog: false});
});

router.get('/paper',(req, res) =>{
    if(req.isAuthenticated())
        res.render('paper',{iLog: true});
    else
        res.render('paper',{iLog: false});
});

router.get('/dashboard', iLog,(req,res) => 
{
    const display = [
        function getworkshop(cb)
        {
            User.findOne({'username': req.user.username},(err,users) => 
            {
                if(err)
                {
                    res.redirect('/');
                    console.log('Error opening dash');
                    res.end();
                }

                var workshoplist = users.workshops;
                console.log("here");
                return cb(null,workshoplist);
            });
        },
        
        function checkAvailability(workshoplist,cb)
        {
		  var closed=[]
		  workshoplist.forEach(function(workshop){
			Workshop.findOne({'name':workshop.workshop_name},function(err, workshops) {
			    if(!workshops.availability)
			    	closed.push(workshops.workshopid);
			});
		  });	
		console.log(closed);
		return cb(null,closed);
	   },

        function details(closed,cb)
        {
            User.findOne({'username':req.user.username}).populate("paperPresentations.team").exec((err,user) => 
            {
                console.log('Outside Loop');
                res.render("dashboard",{user,closed});
            });
        } 
    ];

    waterfall(display,(err,res) => 
    {
        if(err)
        {
            return console.log('Error');
        }
    });
});
//middleware



router.post("/event", iLog, (req, res) => {
    console.log("User name : " + req.user.username);
    console.log(req.body.e_id);
    const regEvent = [

        function getIdForEvent(cb){
            Event.findOne({'name': req.body.e_id}, function(err, events){

                if(err)
                {
                    console.log("Error in call");
                    req.flash('error_msg', 'Try again Later');
                    res.redirect('/dashboard');
                    return;
                }

                if(events == null)
                {
                    console.log("Event does not exist");
                    req.flash("error_msg","Invalid Event");
                    res.redirect('/dashboard');
                    res.end();
                }

                else
                {
                    console.log("Event id:" + events._id);
                    return cb(null,events.name, events.dept);
                }
            });
        },

        function addEventToUser(e_name, e_dept, cb){

            User.findOne({'username': req.user.username, 'events.event_name':e_name}).count(function(err, counts){
                if(err)
                {
                    console.log("Error on updating user - find");
                    req.flash("error_msg","Something went wrong, please try again later");
                    var url = '/'+e_dept;
                    res.redirect(url);
                    res.end();
                }
                else if(!counts)
                {
                    User.updateOne({"username": req.user.username}, {$addToSet:{'events':{'event_name':e_name}}}, (err, users) => {
                        if(err)
                        {
                            console.log("error onf updating user - write");
                            req.flash("error_msg", 'try again later');
                            res.redirect('/dashboard');
                            res.end();
                        }
                        else{
                            console.log("User event updated");
                            req.flash('success_msg',"Registered to event successfully");
                            res.redirect('/'+e_dept);
                            res.end();
                        }
                    });
                }
                else
                {
                    console.log("User already registered");
                    req.flash('error_msg',"You have already registered");
                    res.redirect('/'+e_dept);
                    res.end();
                }
            });
        }
    ];

    waterfall(regEvent, function(err, res){
        if(err)
        {
            console.log("Error in Waterfall Event");
            return;
        }
        console.log('success');
        return;
    })

});

//workshop reg

router.post("/workshop", iLog, (req, res) => {
    console.log("User name : " + req.user.username);
    console.log(req.body.w_id);
    const regWorkshop = [

        function getIdForWorkshop(cb){
            Workshop.findOne({'name': req.body.w_id}, function(err, workshops){

                if(err)
                {
                    console.log("Error in call");
                    req.flash('error_msg', 'Try again Later');
                    res.redirect('/dashboard');
                    return;
                }

                if(workshops == null)
                {
                    console.log("Workshop does not exist");
                    req.flash("error_msg","Invalid Workshop");
                    res.redirect('/dashboard');
                    res.end();
                }

                else
                {
                    console.log("Workshop id:" + workshops._id);
                    return cb(null,workshops.name, workshops.dept,workshops.availability,workshops.open, workshops.workshopid);
                }
            });
        },

        function addWorkshopToUser(w_name, w_dept, avail, status, id, cb){

            User.findOne({'username': req.user.username, 'workshops.workshop_name':w_name}).count(function(err, counts){
                if(err)
                {
                    console.log("Error on updating user - find");
                    req.flash("error_msg","Something went wrong, please try again later");
                    var url = '/'+w_dept;
                    res.redirect(url);
                    res.end();
                }
                else if(!counts)
                {
                    if(status && (avail > 0))
                    {
                        User.updateOne({"username": req.user.username}, {$addToSet:{'workshops':{'workshop_name':w_name, 'workshopid':id }}}, (err, users) => {
                            if(err)
                            {
                                console.log("error on updating user - write");
                                req.flash("error_msg", 'try again later');
                                res.redirect('/dashboard');
                                res.end();
                            }
                            else{
                                console.log("User Workshop updated");
                                req.flash('success_msg',"Registered to Workshop successfully");
                                res.redirect('/'+w_dept);
                                res.end();
                            }
                        });
                    }
                    else
                    {
                        console.log("no availability / closed status");
                        req.flash("error_msg", 'Sorry! Workshop Seats are already filled');
                        res.redirect('/'+w_dept);
                        res.end();
                    }
                }

                else
                {
                    console.log("User already registered");
                    req.flash('error_msg',"You have already registered");
                    res.redirect('/'+w_dept);
                    res.end();
                }
                    
            });
        }
    ];

    waterfall(regWorkshop, function(err, res){
        if(err)
        {
            console.log("Error in Waterfall Event");
            return;
        }
        console.log('success');
        return;
    })

});

router.post("/workshop2", iLog, (req, res) => {
    console.log("User name : " + req.user.username);
    console.log(req.body.w_id);
    const regWorkshop = [

        function getIdForWorkshop(cb){
            Workshop.findOne({'name': req.body.w_id}, function(err, workshops){

                if(err)
                {
                    console.log("Error in call");
                    req.flash('error_msg', 'Try again Later');
                    res.redirect('/dashboard');
                    return;
                }

                if(workshops == null)
                {
                    console.log("Workshop does not exist");
                    req.flash("error_msg","Invalid Workshop");
                    res.redirect('/mech');
                    res.end();
                }

                else
                {
                    console.log("Workshop id:" + workshops._id);
                    return cb(null,workshops.name, workshops.dept,workshops.availability,workshops.open, workshops.workshopid);
                }
            });
        },

        function addEventToUser(w_name, w_dept, avail, status, id, cb){

            User.findOne({'username': req.user.username, 'workshops.workshop_name':w_name}).count(function(err, counts){
                if(err)
                {
                    console.log("Error on updating user - find");
                    req.flash("error_msg","Something went wrong, please try again later");
                    var url = '/'+w_dept;
                    res.redirect(url);
                    res.end();
                }
                else if(!counts)
                {
                    if(status && (avail > 0))
                    {
                        User.updateOne({"username": req.user.username}, {$addToSet:{'workshops':{'workshop_name':w_name, 'workshopid':id }}}, (err, users) => {
                            if(err)
                            {
                                console.log("error on updating user - write");
                                req.flash("error_msg", 'try again later');
                                res.redirect('/dashboard');
                                res.end();
                            }
                            else{
                                console.log("User Workshop updated");
                                req.flash('success_msg',"Registered to Workshop successfully");
                                res.redirect('/'+w_dept);
                                res.end();
                            }
                        });
                    }
                    else
                    {
                        console.log("no availability / closed status");
                        req.flash("error_msg", 'Sorry! Workshop Seats are already filled');
                        res.redirect('/'+w_dept);
                        res.end();
                    }
                }

                else
                {
                    console.log("User already registered");
                    req.flash('error_msg',"You have already registered");
                    res.redirect('/'+w_dept);
                    res.end();
                }
                    
            });
        }
    ];

    waterfall(regWorkshop, function(err, res){
        if(err)
        {
            console.log("Error in Waterfall Event");
            return;
        }
        console.log('success');
        return;
    })

});

function getId(dept)
{
    var deptId=0;
	switch(dept)
	{
		case 'cse':
			deptId = 1;break;
		case 'ece':
			deptId = 2;break;
		case 'mech':
			deptId = 3;break;
		case 'eee':
			deptId = 4;break;
		case 'civil':
            deptId = 5;break;
        case 'ecep':
            deptId = 6;break;
	}
	return deptId;
}

router.post("/paper",iLog,function(req,res)
{
    const teamName = req.body.teamName;
    const teamId = req.body.teamId;

    var dept = req.body.dept;
    console.log(dept);

    if(!req.body.options)
    {
        req.flash("error", 'You forgot to choose an option');
        res.redirect('/paper/'+dept);
    }

    var pdept = getId(dept);
	if(req.body.options == 1)
	{ 
    
        if(teamName == "")
        {
            req.flash("error", 'You forgot to enter team name');
            res.redirect('/paper/'+dept);
        }
        else
        {
            const createPaperTeam = [
                function isTeamExists(cb)
                {
                    Team.findOne({'team_name':req.body.teamName,'paper_id':getId(req.body.dept)}).count(function(err,teams){
                    if(err)
                    {
                        console.log('error');
                        req.flash('error','Try again later');
                        res.redirect('/paper/'+dept);
                        res.end();
                        return;
                    }
                    if(teams)
                    {
                        console.log('Already exist');
                        req.flash('error','Team name already exists');
                        res.redirect('/paper/'+dept);
                        res.end();
                    }
                    else
                        return cb(null);
                    });
                },
                function createNewTeam(cb)
                {
                    console.log('In create team');
                    var team = new Team(
                    {
                        team_name: req.body.teamName,
                        team_members: [],
                        paper_id: getId(req.body.dept)
                    });
                    team.team_members.addToSet(req.user._id);
                    return cb(null,team);
                },
                function addPaperToUser(team,cb)
                {
                    console.log('In AddPaperToUser');
                    User.findOne({'username':req.user.username,'paperPresentations.paper':getId(req.body.dept)}).count(function(err,counts){
                    if(err)
                    {
                        console.log("error");
                        req.flash("error","Please try again later");
                        res.redirect("/paper/"+dept);
                        res.end();
                    }
                    else if(!counts)
                    {
                        team.save(function(err,saved_team)
                        {
                            if(err) 
                            {	
                                req.flash('error','Try again later');
                                console.log('error');
                                res.redirect('/paper/'+dept);
                                res.end();
                                return;
                            }
                        });
                        User.updateOne({"username":req.user.username},{$addToSet:{'paperPresentations':{'team':team._id,'paper':getId(req.body.dept)}}},function(err,users)
                        {
                            if(err)
                            {
                                console.log("error in update");
                                req.flash("error","Try again later");
                                res.redirect('/paper/'+dept);
                                res.end();
                                return;						
                            }
                            else
                            {
                                console.log("Team updated");
                                req.flash("success_msg", "Registered Successfully");
                                console.log(dept);
                                res.redirect('/paper/' + dept);
                                return;
                            }
                        });
                    }
                    else if(counts>0)
                    {
                        console.log("You already registered");
                        req.flash("error",'You have registered already');
                        res.redirect('/paper'+dept);
                        res.end();
                    }
                    });
                    }	
                ];
                
                waterfall(createPaperTeam,function(err,res){
                    if(err)
                    {
                        req.flash("error",'Try again later');
                        console.log('Error in waterfall');
                        return;
                    }
                    console.log('Success');
                    return;
                });
                
        }
	    
	}				
		else if(req.body.options == 2 )
		{	

            if(teamId == "")
            {
                req.flash("error", 'You forgot to enter Team ID');
                res.redirect('/paper/'+dept);
            }

            else
            {
                var joinPaperTeam = [
                    function  isIdValidAndExists(cb)
                    {
                        if(!mongoose.Types.ObjectId.isValid(req.body.teamId))
                        {
                            console.log('Not a valid team id');
                            req.flash("error","Enter correct ID to join the team");
                            res.redirect("/paper/" + dept);
                            return;
                        }	
                        else
                        {
                            Team.findOne({'_id':req.body.teamId,'paper_id':pdept},function(err,teams){
                            console.log('teams:'+teams);
                                if(err)
                                {
                                    req.flash("error","Team not found");
                                    res.redirect("/paper/"+dept);
                                    res.end();
                                    return;
                                }
                                else if(!teams)
                                {
                                    console.log("team not found");
                                    req.flash("error","Team Not Found");
                                    res.redirect("/paper/"+dept);
                                    res.end();
                                    return;
                                }
                                else
                                {
                                    return cb(null,teams);
                                }
                            });
                        }
                    },
                    function isUserRegistered(teams,cb)
                    {
                        Team.findOne({'_id':req.body.teamId,'team_members':req.user._id}).count(function(err,counts){
                            if(err)
                            {
                                req.flash("error",'Try again later');
                                res.redirect("/paper/" + dept);
                                res.end();
                                return;
                            }
                            else
                            {
                                console.log('c'+counts);
                                if(counts!=0)
                                {
                                    console.log('Already joined the team!');
                                    req.flash("error","Already joined");
                                    res.redirect("/paper/" + dept);
                                    console.log("redirected");
                                    return;
                                }
                                else
                                    return cb(null,teams);
                            }
                        });
                    },
                    function checkTeamLen(teams,cb)
                    {
                        temp_mem = [];
                        temp_mem = temp_mem.concat(teams.team_members);
                        if(temp_mem.length>=2)
                        {
                            console.log("more than 2");
                            req.flash("error","Team you requested to join already has 2 members");
                            res.redirect("/paper/" + dept);
                            return;
                        }
                        else
                            return cb(null,temp_mem);
                    },
                    function addToTeam(temp_mem,cb)
                    {
                        temp_mem.push(req.user._id);
                        Team.findByIdAndUpdate(req.body.teamId,{$set:{'team_members':temp_mem}},function(err,teams){
                            if(err)
                            {
                                console.log('error in adding to team');
                                req.flash("error","Try again later");
                                res.redirect("/paper/" + dept);
                                res.end();
                                return;
                            }
                            else
                            {
                                console.log('team id'+teams._id);
                                return cb(null,teams);
                            }
                        });
                    },
                    function addToUser(teams,cb)
                    {
                        console.log('team id'+teams._id);
                        User.update({'username':req.user.username},{$addToSet:{'paperPresentations':{'paper':pdept,'team':teams._id}}},function(err,users){
                            if(err)
                            {
                                req.flash("error","Try again later");
                                console.log('Error in adding to user');
                                res.redirect('/paper/' + dept);
                                res.end();
                                return;
                            }
                            else{
                                console.log('successfully added to team');
                                req.flash("success_msg","Added to team successfully");
                                res.redirect("/paper/" + dept);
                                return;
                            }
                        });
                    }
                ];
                
                waterfall(joinPaperTeam,function(err,results){
                    if(err)
                    {
                        req.flash("error",'Try again later');
                        console.log('Error in waterfall');
                        return;
                    }
                    console.log('Success');
                    return;
                });
            
                temp_mem = [];
            }

			
		}
});

router.post("/project",iLog,function(req,res)
{
    const teamName = req.body.teamName;
    const teamId = req.body.teamId;

    var dept = req.body.dept;
    console.log(dept);

    if(!req.body.options)
    {
        req.flash("error", 'You forgot to choose an option');
        res.redirect('/project/'+dept);
    }

    var pdept = getId(dept);
	if(req.body.options == 1)
	{ 
    
        if(teamName == "")
        {
            req.flash("error", 'You forgot to enter team name');
            res.redirect('/project/'+dept);
        }
        else
        {
            const createProjectTeam = [
                function isTeamExists(cb)
                {
                    Team.findOne({'team_name':req.body.teamName,'paper_id':getId(req.body.dept)}).count(function(err,teams){
                    if(err)
                    {
                        console.log('error');
                        req.flash('error','Try again later');
                        res.redirect('/project/'+dept);
                        res.end();
                        return;
                    }
                    if(teams)
                    {
                        console.log('Already exist');
                        req.flash('error','Team name already exists');
                        res.redirect('/project/'+dept);
                        res.end();
                    }
                    else
                        return cb(null);
                    });
                },
                function createNewTeam(cb)
                {
                    console.log('In create team');
                    var team = new Team(
                    {
                        team_name: req.body.teamName,
                        team_members: [],
                        paper_id: getId(req.body.dept)
                    });
                    team.team_members.addToSet(req.user._id);
                    return cb(null,team);
                },
                function addProjectToUser(team,cb)
                {
                    console.log('In AddProjectToUser');
                    User.findOne({'username':req.user.username,'paperPresentations.paper':getId(req.body.dept)}).count(function(err,counts){
                    if(err)
                    {
                        console.log("error");
                        req.flash("error","Please try again later");
                        res.redirect("/project/"+dept);
                        res.end();
                    }
                    else if(!counts)
                    {
                        team.save(function(err,saved_team)
                        {
                            if(err) 
                            {	
                                req.flash('error','Try again later');
                                console.log('error');
                                res.redirect('/project/'+dept);
                                res.end();
                                return;
                            }
                        });
                        User.updateOne({"username":req.user.username},{$addToSet:{'paperPresentations':{'team':team._id,'paper':getId(req.body.dept)}}},function(err,users)
                        {
                            if(err)
                            {
                                console.log("error in update");
                                req.flash("error","Try again later");
                                res.redirect('/project/'+dept);
                                res.end();
                                return;						
                            }
                            else
                            {
                                console.log("Team updated");
                                req.flash("success_msg", "Registered Successfully");
                                console.log(dept);
                                res.redirect('/project/' + dept);
                                return;
                            }
                        });
                    }
                    else if(counts>0)
                    {
                        console.log("You already registered");
                        req.flash("error",'You have registered already');
                        res.redirect('/project'+dept);
                        res.end();
                    }
                    });
                    }	
                ];
                
                waterfall(createProjectTeam,function(err,res){
                    if(err)
                    {
                        req.flash("error",'Try again later');
                        console.log('Error in waterfall');
                        return;
                    }
                    console.log('Success');
                    return;
                });
                
        }
	    
	}				
		else if(req.body.options == 2 )
		{	

            if(teamId == "")
            {
                req.flash("error", 'You forgot to enter Team ID');
                res.redirect('/project/'+dept);
            }

            else
            {
                var joinProjectTeam = [
                    function  isIdValidAndExists(cb)
                    {
                        if(!mongoose.Types.ObjectId.isValid(req.body.teamId))
                        {
                            console.log('Not a valid team id');
                            req.flash("error","Enter correct ID to join the team");
                            res.redirect("/project/" + dept);
                            return;
                        }	
                        else
                        {
                            Team.findOne({'_id':req.body.teamId,'paper_id':pdept},function(err,teams){
                            console.log('teams:'+teams);
                                if(err)
                                {
                                    req.flash("error","Team not found");
                                    res.redirect("/project/"+dept);
                                    res.end();
                                    return;
                                }
                                else if(!teams)
                                {
                                    console.log("team not found");
                                    req.flash("error","Team Not Found");
                                    res.redirect("/project/"+dept);
                                    res.end();
                                    return;
                                }
                                else
                                {
                                    return cb(null,teams);
                                }
                            });
                        }
                    },
                    function isUserRegistered(teams,cb)
                    {
                        Team.findOne({'_id':req.body.teamId,'team_members':req.user._id}).count(function(err,counts){
                            if(err)
                            {
                                req.flash("error",'Try again later');
                                res.redirect("/project/" + dept);
                                res.end();
                                return;
                            }
                            else
                            {
                                console.log('c'+counts);
                                if(counts!=0)
                                {
                                    console.log('Already joined the team!');
                                    req.flash("error","Already joined");
                                    res.redirect("/project/" + dept);
                                    console.log("redirected");
                                    return;
                                }
                                else
                                    return cb(null,teams);
                            }
                        });
                    },
                    function checkTeamLen(teams,cb)
                    {
                        temp_mem = [];
                        temp_mem = temp_mem.concat(teams.team_members);
                        if(temp_mem.length>=4)
                        {
                            console.log("more than 4");
                            req.flash("error","Team you requested to join already has 4 members");
                            res.redirect("/project/" + dept);
                            return;
                        }
                        else
                            return cb(null,temp_mem);
                    },
                    function addToTeam(temp_mem,cb)
                    {
                        temp_mem.push(req.user._id);
                        Team.findByIdAndUpdate(req.body.teamId,{$set:{'team_members':temp_mem}},function(err,teams){
                            if(err)
                            {
                                console.log('error in adding to team');
                                req.flash("error","Try again later");
                                res.redirect("/project/" + dept);
                                res.end();
                                return;
                            }
                            else
                            {
                                console.log('team id'+teams._id);
                                return cb(null,teams);
                            }
                        });
                    },
                    function addToUser(teams,cb)
                    {
                        console.log('team id'+teams._id);
                        User.update({'username':req.user.username},{$addToSet:{'paperPresentations':{'paper':pdept,'team':teams._id}}},function(err,users){
                            if(err)
                            {
                                req.flash("error","Try again later");
                                console.log('Error in adding to user');
                                res.redirect('/project/' + dept);
                                res.end();
                                return;
                            }
                            else{
                                console.log('successfully added to team');
                                req.flash("success_msg","Added to team successfully");
                                res.redirect("/project/" + dept);
                                return;
                            }
                        });
                    }
                ];
                
                waterfall(joinProjectTeam,function(err,results){
                    if(err)
                    {
                        req.flash("error",'Try again later');
                        console.log('Error in waterfall');
                        return;
                    }
                    console.log('Success');
                    return;
                });
            
                temp_mem = [];
            }

			
		}
});

//route for android get login - paper and project presentations
router.get("/android/presentation/:mode/:dept/:username/:password",function(req,res,next){
    req.body.username = req.params.username;
    req.body.password = req.params.password;
    passport.authenticate('local',function(err,user,info){
        if (err) { return next(err); }
        if (!user) {
            console.log("invalid details")
            return res.redirect('/user/login');
        }
        req.logIn(user,function(err){
            if(err){ return next(err) }
            console.log("android redirect authentication successfull")
            if(req.params.mode=='paper')
                return res.redirect('/paper/'+req.params.dept);
            else if(req.params.mode=='project')
                return res.redirect('/project/'+req.params.dept);
            else
            {
                req.flash("err_msg","Path not found");
                return res.redirect('/about');
            }
        });
    })(req,res,next);
});

//route for android get login - payment
router.get("/android/onlinepayment/:e_id/:username/:password",function(req,res,next){
    req.body.username = req.params.username;
    req.body.password = req.params.password;
    passport.authenticate('local',function(err,user,info){
        if (err) { return next(err); }
        if (!user) {
            console.log("invalid details")
            return res.redirect('/users/login');
        }
        req.logIn(user,function(err){
            if(err){ return next(err) }
            console.log("android redirect authentication successfull")
            return res.redirect('/onlinepayment/'+req.params.e_id)
        });
    })(req,res,next);
});


//Encryption and Decryption

const ENCRYPTION_KEY = "31a4135318fb765bb037aa53ee1ed3ed"; // 32 BYTE KEY
const IV_LENGTH = 16; // For AES, this is always 16


function hashsha(text){
    var hash = crypto.createHash('sha256').update(text).digest('base64');
    return hash;
}

function encrypt(text) {
  let iv = new Buffer("4690ed68f7b720fcbe2b820d8307cb67","hex");
  
  let cipher = crypto.createCipheriv('aes-256-cbc', ENCRYPTION_KEY, iv);
  let encrypted = cipher.update(text);

  encrypted = Buffer.concat([encrypted, cipher.final()]);

  return (encrypted.toString('base64'));
  
  
  
}

function decrypt(text) {
  
  let iv =new Buffer( "4690ed68f7b720fcbe2b820d8307cb67",'hex');
  
  let encryptedText = new Buffer(text,'base64');
  let decipher = crypto.createDecipheriv('aes-256-cbc', (ENCRYPTION_KEY), iv);
  let decrypted = decipher.update(encryptedText);

  decrypted = Buffer.concat([decrypted, decipher.final()]);

  return decrypted.toString();
}


function verify(text)
{
    var dt=(text);
    var hash=dt.substring(dt.length-44);
    
    var mac=(hashsha(dt.substring(0,dt.length-44)));
    if(hash==mac)
        return (true);
    else
        return (false);
}
function extract(dt)
{
    return dt.substring(0,dt.length-44);
}

/*var text=(encrypt("YUK19101&1&31"+hashsha("YUK19101&1&31")));
console.log(text);
console.log(decrypt("B51immeomUKwOKOyhWH3lFqHojfHunlFbunT8E7YUcrZKFSUQvTZ9g+XZPyfd5LpHWrOpdxoLtOhSE8K/qbCcg=="));*/

//Online Payment
router.get("/onlinepayment/:eventid",iLog,function(req,res){
	console.log(req.user.username);
	
	User.findOne({username:req.user.username},function(err, user) {
	   console.log(user); 
	   var userid = user.yukid;
	   userid="YUK"+String(userid);
	   console.log(userid);
	   var username = user.username;
	   var mobileno = user.phoneNo;
	   var eventid = req.params.eventid;
	   console.log(eventid);
	   if(eventid=='31')
	   {
	   	   console.log('----------EVENT__ID----------');
	   	   const amount = 400;
		   
		   var encstring =( String("userid="+userid+"&username="+username+"&mobileno="+mobileno+"&eventid="+eventid+"&amount="+amount));
		   encstring+=hashsha(encstring);
		   encstring=encrypt(encstring);
           console.log(encstring);
           console.log(decrypt(encstring));
		   res.redirect("https://ecampus.psgtech.ac.in/yukta/yukta.aspx?enc="+encstring);
	   }
	   else
	   {
	   			Workshop.findOne({workshopid:Number(eventid)},function(err, workshop) {
	   			if(workshop && workshop.availability>0)
	   			{
                    var amount;
                    if(user.epaid || user.spaid)
                    {
                           amount= workshop.fee - 400;
                           
                    }
                    else
                            amount = workshop.fee; 
                            
		   		    console.log('----------------------------------------')
		   		    console.log(amount);
		   		    var encstring =( String("userid="+userid+"&username="+username+"&mobileno="+mobileno+"&eventid="+eventid+"&amount="+amount));
					 encstring+=hashsha(encstring);
                     encstring=encrypt(encstring);
                     console.log("DECRYPTED : " + decrypt(encstring));
					console.log(encstring);
					res.redirect("https://ecampus.psgtech.ac.in/yukta/yukta.aspx?enc="+encstring);
	   			}
	   			else
	   			{
					console.log("comes here at payment");
	   				
                       res.redirect("/dashboard");
                       req.flash('error_msg', 'Sorry! No more seats available.');
	   			}  
	   		});
	   }
	});
});

router.get("/onlinepayment/return/:dump*",function(req,res)
{
	
    var params=req.params; 
	var text = params['dump']+params['0'];
	console.log("t val 0 : "+text);
	if(text[0]=='a' && text[1]=='&')
	{
		text=text.split('&')[1];
		console.log("t val 1 : "+text);
	}
	
	try{
	var oreturn = decrypt(text);
	console.log("oreturn===="+oreturn);
		}
	catch(error){
		req.flash("error_msg","Payment Failed, Try again later");
	    res.redirect("/dashboard");
		res.end();
	    return;
	}
	console.log('H'+oreturn);
	if(verify(oreturn)==true){
		oreturn=extract(oreturn);
		console.log('oreturn:'+oreturn);
		var details = oreturn.split('&');
		var obid= details[0];
		var statuscode=details[1];
		var eventid = details[2];
        console.log('details:'+details);
        var y_id = oreturn.slice(3,9);
		console.log(y_id);
		if(eventid==31)
		{
			if(statuscode=='1')
			{
				User.updateOne({"yukid":y_id},{"epaid":true},function(err, user) {
				if(err)
		    		{
		    		console.log(err);
					req.flash('error_msg','Try again later');
					res.redirect('/dashboard');
		    		res.end();
		    		}
		    		else
		    		{
                
                        User.find({"yukid":y_id},function(err, user) {

                            var mail = user[0].toObject().username;
                            console.log("inside success " + user[0].toObject().username);
					        var mailOptions = {
                            from: "yukta@psgitech.ac.in",
                            to: mail,
                            subject: "YUKTAHA 2k20 Payment Confirmation",
                            generateTextFromHTML: true,
                          html: "<p>Congratulations! Your payment has been processed successfully. We wish you all the best and hope to see you here.</p><br>Your Yuktaha id:<b>YUK"+user[0].toObject().yukid+"</b><br><a href='https://yuktaha.psgitech.ac.in/'>Website link:<b> https://yuktaha.psgitech.ac.in/</b></a></b><br><b>Contact name</b>:Shri Hari S<br><b>Contact no</b>:8754735353<br><br><b>Contact name</b>:Arun Soorian V<br><b>Contact no</b>:8300497492<br>With regards,<br>Team-Yuktaha"
                        };

                        smtpTransport.sendMail(mailOptions, (error, data) => {
                            error ? console.log(error) : console.log(data);
                            smtpTransport.close();
                        });
                       
                        });
		    			
		    			req.flash("success_msg","Payment Successful");
		    			res.redirect("/dashboard");
		    			return;
		    		}
		    	}
		    	);
			}	
		    else
		    {
		    	req.flash("error_msg","Payment Failed, Try again later");
		    	res.redirect("/dashboard");
		    	return;
		    }
		}
		else{
			const updatePaymentTasks = [
				function setEPaid(cb)
				{
					if(statuscode!='1')
					{
						console.log('payment unsuccessful');
						req.flash('error_msg','Try again later');
						res.redirect('/dashboard');
						res.end();
						return;
					}
					console.log('In set epaid'+Number(eventid));
					User.updateOne({'yukid':y_id,'workshops.workshopid':Number(eventid)},{'epaid':true},function(err,users){
						if(err)
						{
							console.log('Error in accessing user');
							req.flash('error_msg','Try again later');
							res.redirect('/dashboard');
							res.end();
						}
						console.log('epaid updated');
						return cb(null,eventid);
					})
				},
				function getWorkshopName(eventid,cb)
				{
					console.log('getting id'+eventid);
					User.findOne({'yukid':y_id,'workshops.workshopid':Number(eventid)},function(err,users){
						if(err)
						{
							console.log('Error in getting user');
							req.flash('error_msg','Try again later');
							res.redirect('/dashboard');
							res.end();
							return;
						}
						if(users.workshops ==null)
						{
							console.log('Not yet registered');
							req.flash('error_msg','Try again later');
							res.redirect('/dashboard');
							res.end();
							return;
						}
						console.log(users.workshops+'Here');
						users.workshops.forEach(function(val){
							if(val.workshopid==Number(eventid))
							{
								console.log('found'+val.workshop_name);
								return cb(null,val.workshop_name);
							}
						});
						console.log('ending');
					})
				},
				function setWpaid(wname,cb)
				{
					console.log('In set wpaid');                   
                    User.update({'yukid':y_id,'workshops.workshopid':Number(eventid)},{$set:{'workshops.$.wpaid':true}}, function(err,user)
                    {
                        if(err)
					    {
					    console.log('Error in updating payment to User');
						req.flash('error_msg','Try again later');
						res.redirect('/dashboard');
					    res.end();
                        }
                        else
		    		    {
                
                            User.find({"yukid":y_id},function(err, user) {

                                var mail = user[0].toObject().username;
                                console.log("inside success " + user[0].toObject().username);
					            var mailOptions = {
                                from: "yukta@psgitech.ac.in",
                                to: mail,
                                subject: "YUKTAHA 2k20 Payment Confirmation",
                                generateTextFromHTML: true,
                            html: "<p>Congratulations! Your payment has been processed successfully. We wish you all the best and hope to see you here.</p><br>Your Yuktaha id:<b>YUK"+user[0].toObject().yukid+"</b><br><a href='https://yuktaha.psgitech.ac.in/'>Website link:<b> https://yuktaha.psgitech.ac.in/</b></a></b><br><b>Contact name</b>:Shri Hari S<br><b>Contact no</b>:8754735353<br><br><b>Contact name</b>:Arun Soorian V<br><b>Contact no</b>:8300497492<br>With regards,<br>Team-Yuktaha"
                            };

                            smtpTransport.sendMail(mailOptions, (error, data) => {
                                error ? console.log(error) : console.log(data);
                                smtpTransport.close();
                            });
                       
                            });
		    			    
                            
						    return cb(null,wname);
                        }
                        
                        });
                    },


				function decreaseAvailability(wname,cb)
				{
					
					console.log('in dec avail'+wname);
					Workshop.update({'name':wname},{$inc:{'availability':-1}},function(err,workshops){
						if(err)
						{
							console.log('Error in reducing count');
							req.flash('error_msg','Payment failed');
							res.redirect("/dashboard");
							res.end();
						}
						else 
						{
							console.log('Success');
							req.flash('success_msg','Payment successful!');
							res.redirect("/dashboard");
							res.end();
						}
					});
				}
				]
			waterfall(updatePaymentTasks,function(res,err){
				if(err)
				{
					console.log('error in updating payment');
				}
				console.log('success');
				res.end();
			});
		}
    }
    else
    {
    	req.flash("error_msg","payment failed try again later");
	    res.redirect("/dashboard");	
		return;
    }
});



//handle add events

router.post('/add_event', (req, res) => {
    
    Event.findOne({name : req.body.e_name})
        .then(event => {
            if(event){
                console.log("Exists" + event.name);
                res.render("/add_event");
            }

            else{
                const newEvent = new Event({
                    name: req.body.e_name,
                    dept: req.body.d_name
                });

                newEvent.save().then(event => {
                    console.log("Added");
                    res.redirect("/add_event");
                }).catch(err => console.log(err));
            }
        })
});

router.post('/add_paper', (req, res) => {

    Paper.findOne({pname : req.body.p_name})

        .then(paper => {
            if(paper){
                console.log(paper.pname + "Exists");
                res.render("/add_paper");
            }
            else
            {
                const newPaper = new Paper({
                    pname : req.body.p_name,
                    department: req.body.d_name,
                    _id: req.body.id
                });

                newPaper.save().then(paper => {
                    console.log("Added");
                    res.redirect("/add_paper");
                }).catch(err => console.log(err));
            }
        })
});

router.post('/add_workshop', (req, res) => {
    
    Workshop.findOne({name : req.body.w_name})
        .then(workshop => {
            if(workshop){
                console.log("Exists" + workshop.name);
                res.render("/add_workshop");
            }

            else{
                const newWorkshop = new Workshop({
                    name: req.body.w_name,
                    dept: req.body.d_name,
                    availability: req.body.avail,
                    fee: req.body.fee
                });

                newWorkshop.save().then(workshop => {
                    console.log("Added");
                    res.redirect("/add_workshop");
                }).catch(err => console.log(err));
            }
        })
});


module.exports = router;
