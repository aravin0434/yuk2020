const express = require('express');
const router = express.Router();
const User = require('../models/User');
const passport = require('passport');
const LocalStrategy = require("passport-local");
const nodemailer = require('nodemailer');
const { google } = require('googleapis');
const OAuth2 = google.auth.OAuth2;
const {iLog, iNLog} = require('../config/auth');

// automate email

const oauth2Client = new OAuth2(
    "293583068886-3lg508q3uldbe5kbjepui7dn48fjoq3i.apps.googleusercontent.com",
    "YjwJ_8ZGAmhRY3fSDSkZ3X0c",
    "https://developers.google.com/oauthplayground"
);


oauth2Client.setCredentials({
    refresh_token: "1//04XX8u0OIjZRlCgYIARAAGAQSNwF-L9IrupXNGSplIZUaVq8E1jjpiWOzqrtCfMmDiTb7MOT-G_p8hLPdvRPjD288hVevZS9o6jc"
});
const accessToken = oauth2Client.getAccessToken();

/*let transporter = nodemailer.createTransport({
    host: 'smtp.gmail.com',
    port: 587,
    secure: false,
    auth: {
        user: 'yukta@psgitech.ac.in',
        pass: 'qnzllgjyicgktoqy'
    }
});*/

const smtpTransport = nodemailer.createTransport({
    service: "gmail",
    auth: {
         type: "OAuth2",
         user: "yukta@psgitech.ac.in", 
         clientId: "293583068886-3lg508q3uldbe5kbjepui7dn48fjoq3i.apps.googleusercontent.com",
         clientSecret: "YjwJ_8ZGAmhRY3fSDSkZ3X0c",
         refreshToken: "1//04XX8u0OIjZRlCgYIARAAGAQSNwF-L9IrupXNGSplIZUaVq8E1jjpiWOzqrtCfMmDiTb7MOT-G_p8hLPdvRPjD288hVevZS9o6jc",
         accessToken: accessToken
    }
});


passport.use(new LocalStrategy(User.authenticate()));
passport.serializeUser(User.serializeUser());
passport.deserializeUser(User.deserializeUser());


//User model

//login 
router.get('/login', iNLog,(req, res) =>{
    res.render('login', {default: "login"});
});

//signup
router.get('/signup', iNLog,(req, res) =>{
    res.render('signup', {default: "signup"});
});

//Signup Handle
/*router.post('/signup', (req, res) => {
    const { name, username, password, phoneNo, year, department, collegeName } = req.body;
    let errors = [];

    //Check required fields
    if(!name || !username || !password || !phoneNo || !year || !department || !collegeName){
        errors.push({msg: 'Please fill in all fields'});
    }

    //check pass length
    if(password.length < 6){
        errors.push({msg: 'Password must be atleast 6 characters'});
    }

    if(errors.length > 0){
        res.render('signup1',{
            errors,
            name,
            username,
            password,
            phoneNo,
            year,
            department,
            collegeName,
            default: "signup"      
        });
    }
    else{
        //validation passed
        User.findOne({ username: username })
            .then(user => {
                if(user){
                    //User exists
                    errors.push({msg: 'Email is already signed up'});
                    res.render('signup1',{
                        errors,
                        name,
                        username,
                        password,
                        phoneNo,
                        year,
                        department,
                        collegeName,
                        default: "signup"
                    });
                }
                else {
                    const newUser = new User({
                        name,
                        username,
                        password,
                        phoneNo,
                        year,
                        department,
                        collegeName
                    });
                    // Hash password

                    bcrypt.genSalt(10, (err, salt) => {
                        bcrypt.hash(newUser.password, salt, (err, hash) => {
                            if(err) throw err;
                            // set hashed pwd
                            newUser.password = hash;
                            // Save user
                            newUser.save()
                                .then(user => {
                                    req.flash('success_msg', 'You are now signed up and can log in');
                                    res.redirect('/users/login');

                                    var mailOptions = {
                                        from: "YUK <yukta@psgitech.ac.in>",
                                        to: req.body.username,
                                        subject: "YUKTAHA Sign Up",
                                        generateTextFromHTML: true,
                                        html: "<p>Thank you for signing up for Yuktaha. Your application has been processed successfully.<br><br>Your Yuktaha id: <b>YUK"+user.yukid+"</b><br> Password: <b>"+req.body.password+"</b><br><br><b>Download the official yuktaha app: <a href='https://play.google.com/store/apps/details?id=psgitech.yuktaha.symposium.test1'>https://play.google.com/store/apps/details?id=psgitech.yuktaha.symposium.test1</a></b><br><b>This app will be identified as your ID card throughout the yuktaha experience.</b><br><br>The <b>unique QR CODE</b> which is generated for you can be found in the app's <b>Dashboard</b> section, and will be used for authentication, awarding winners, on the spot payment of general event fee and much more.<br>The app also has other unique features like the college <b>Leaderboard</b> where you can keep checking the best performing colleges, and the <b>Achievers</b> section which will display the winners of each event. <br>Please download the app before coming to yuktaha for a smoother overall experience.<br><br>We wish you all the best and hope to see you here.<br><br><b>NOTE : </b>For other platform users, your QR code will be displayed on the website dashboard on the day of yuktaha. (only on iOS and windows mobile devices) <br><br>Website link: <a href='https://yuktaha.psgitech.ac.in/'><b>https://yuktaha.psgitech.ac.in/</b></a><br><b>Contact name</b>:Hariharan K<br><b>Contact no</b>:9488964327<br><br>With regards,<br>Team-Yuktaha</p>"
                                    };
                
                                    smtpTransport.sendMail(mailOptions, (error, data) => {
                                        error ? console.log(error) : console.log(data);
                                        smtpTransport.close();
                                    });
                                })
                                .catch(err => console.log(err));
                        });

                    });                    
                    
                }
            })
            .catch((err) => {
                console.log(err + "error during signup");
            });
    }
});*/

router.post('/signup', (req, res) => {

    User.register(new User({username: req.body.username,
                            name: req.body.name,
                            phoneNo: req.body.phoneNo,
                            year: req.body.year,
                            department: req.body.department,
                            collegeName: req.body.collegeName,
                            epaid: false}),req.body.password,(err, user) => {
                               if(err){
                                   req.flash("error_msg", err.message);
                                   res.redirect('signup');
                                   return;
                               }
                               else{
                               passport.authenticate("local")(req, res, function(){
                                    
                                    req.flash("success_msg","Welcome " + req.body.name + " ");
                                    res.redirect("/dashboard");

                                    User.findOne({'username':req.user.username},function(err, users) {
                                        if(err)
                                        {
                                            req.flash("error",err.message);
                                            res.redirect("/users/login");
                                            return;
                                        }

                                        var mailOptions = {
                                            from: "YUK <yukta@psgitech.ac.in>",
                                            to: req.body.username,
                                            subject: "YUKTAHA Sign Up",
                                            generateTextFromHTML: true,
                                            html: "<p>Thank you for signing up for Yuktaha. Your application has been processed successfully.<br><br>Your Yuktaha id: <b>YUK"+user.yukid+"</b><br> Password: <b>"+req.body.password+"</b><br><br><b>Download the official yuktaha app: <a href='https://play.google.com/store/apps/details?id=psgitech.symposium.yuktaha'>https://play.google.com/store/apps/details?id=psgitech.symposium.yuktaha</a></b><br><b>This app will be identified as your ID card throughout the yuktaha experience.</b><br><br>The <b>unique QR CODE</b> which is generated for you can be found in the app's <b>Dashboard</b> section, and will be used for authentication, awarding winners, on the spot payment of general event fee and much more.<br>The app also has other unique features like the college <b>Leaderboard</b> where you can keep checking the best performing colleges, and the <b>Achievers</b> section which will display the winners of each event. <br>Please download the app before coming to yuktaha for a smoother overall experience.<br><br>We wish you all the best and hope to see you here.<br><br><b>NOTE : </b>For other platform users, your QR code will be displayed on the website dashboard on the day of yuktaha. (only on iOS and windows mobile devices) <br><br>Website link: <a href='https://yuktaha.psgitech.ac.in/'><b>https://yuktaha.psgitech.ac.in/</b></a><br><b>Contact name</b>:SANDHEEP D<br><b>Contact no</b>:7418865467<br><br><b>Contact name</b>:KARTHICK N<br><b>Contact no</b>:8056958851<br><br><b>Contact name</b>:ARUN R<br><b>Contact no</b>:7094376596<br><br><b>Contact name</b>:ASHWIN BALAJI S<br><b>Contact no</b>:7904274660<br><br>With regards,<br>Team-Yuktaha</p>"
                                        };
                    
                                        smtpTransport.sendMail(mailOptions, (error, data) => {
                                            error ? console.log(error) : console.log(data);
                                            smtpTransport.close();
                                        });
                               });
                            });
                        }
                        });
    
});
router.post("/login", iNLog,passport.authenticate("local", {
    successRedirect: "/dashboard",
    failureRedirect: '/users/login',
    successFlash: true,
    failureFlash: true
}),(req, res) => {
    req.flash("success_msg", "Successfully logged in");
});
//Logout handle
router.get('/logout', iLog,(req, res) => {
    req.logout();
    req.flash('success_msg','You are logged out');
    res.redirect('/users/login');
});

passport.serializeUser((user, done) => {
    done(null, user.id);
  });
  
  passport.deserializeUser((id, done) => {
    User.findById(id, function(err, user) {
      done(err, user);
    });
  });

module.exports = router;