var mongoose = require("mongoose");

var TeamSchema = new mongoose.Schema({
	team_name: String,
	team_members:[],
	paper_id: Number
});


module.exports = mongoose.model("Team", TeamSchema);
