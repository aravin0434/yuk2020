var mongoose = require("mongoose");
var AutoIncrement = require("mongoose-sequence")(mongoose)
var receptionistSchema = new mongoose.Schema({
        _id:Number,
        count:Number,
        loggedIn:{type:Boolean,default:false}
    }, { _id:false }
);
receptionistSchema.plugin(AutoIncrement, {inc_field:"_id"})
module.exports= mongoose.model("Receptionist", receptionistSchema);