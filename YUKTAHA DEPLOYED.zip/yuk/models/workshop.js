var mongoose = require("mongoose");
var AutoIncrement = require('mongoose-sequence')(mongoose);
var workshopSchema = new mongoose.Schema(
    {
        name:String,
        dept:String,
        workshopid:Number,
        open:{type:Boolean,default:true},
        availability:Number,
        fee:Number,
        team_count:Number
    }
);
workshopSchema.plugin(AutoIncrement, {inc_field: 'workshopid'});
module.exports=mongoose.model("Workshop",workshopSchema);
