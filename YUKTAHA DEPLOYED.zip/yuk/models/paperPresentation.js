var mongoose = require("mongoose");
// create objects for each paper presentation
var paperPresentationSchema = new mongoose.Schema(
    {
        _id:String,
        pname:String,
        department: String
    }
);
module.exports= mongoose.model("paperPresentation",paperPresentationSchema);