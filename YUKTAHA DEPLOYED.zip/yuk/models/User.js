var mongoose = require("mongoose");
var passportLocalMongoose = require("passport-local-mongoose");
var AutoIncrement = require("mongoose-sequence")(mongoose)

var UserSchema = new mongoose.Schema({
    yukid:Number,
    username: String,
    password: String,
    name: String,
    year: String,
    collegeName: String,
    phoneNo: String,
    department: String,
    epaid: { type:Boolean, default: false},
    spaid: { type:Boolean, default: false},
    events:[{
        _id:false,
        event_name:String
    }],
    workshops:[{
        _id:false,
        workshop_name:String,
        workshopid:Number,
        wpaid: { type:Boolean, default: false}
    }],
      paperPresentations:[{
		_id:false,
		paper:Number,
		team:{
			type:mongoose.Schema.Types.ObjectId,
			ref :"Team"
		}
    }]
});

UserSchema.plugin(passportLocalMongoose);
UserSchema.plugin(AutoIncrement, {inc_field:"yukid"})

module.exports = mongoose.model("User", UserSchema);