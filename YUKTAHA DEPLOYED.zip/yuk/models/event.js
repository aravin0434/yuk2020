var mongoose = require("mongoose");
var AutoIncrement = require('mongoose-sequence')(mongoose);
var eventSchema = new mongoose.Schema({
        name:String,
        dept:String,
        eventid:Number,
        team_count:Number, //Team size allowed
        winners:[           // Winners (array of array)
            [{
                _id: false,
                name: String,
                collegeName: String
            }]
        ]
});
eventSchema.plugin(AutoIncrement, {inc_field: 'eventid'});
module.exports= mongoose.model("Event",eventSchema);
