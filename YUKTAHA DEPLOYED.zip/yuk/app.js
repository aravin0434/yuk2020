const express = require('express');
//const expressLayouts = require('express-ejs-layouts');
const mongoose = require('mongoose');
const flash = require('connect-flash');
const session = require('express-session');
const passport = require('passport');
const path = require('path');
const passportLocalMongoose = require('passport-local-mongoose');
const compression = require('compression');
const User = require('./models/User');
const Event = require('./models/event');
const Paper = require('./models/paperPresentation');
const app = express();

app.use(compression());
//Passport config
//require('./config/passport')(passport);

//swapped with DB config of MONGO ATLAS
//DB config
mongoose.connect('mongodb://127.0.0.1/yuk', { useNewUrlParser: true, useUnifiedTopology: true, useCreateIndex: true});
const db = mongoose.connection;

//check connection
db.once('open', function(){
    console.log('Connected to MongoDB')
});4

//check for db errors
db.on('error', function(){
    console.log(err);
});

//EJS
//app.use(expressLayouts);
app.set('view engine', 'ejs');
app.use(express.static(__dirname + "/public"))

//BodyParser
app.use(express.urlencoded({extended: true}));

//Express Session middleware
app.use(session({
    secret: 'YUK2020',
    resave: true,
    saveUninitialized: true,
}));

app.use(passport.initialize());
app.use(passport.session());

//connect flash middleware
app.use(flash());

//GLOBAL VARS
app.use((req, res, next) =>{
    res.locals.success_msg = req.flash('success_msg');
    res.locals.error_msg = req.flash('error_msg');
    res.locals.error = req.flash('error');
    next();
} );

function getId(dept)
{
    var deptId=0;
	switch(dept)
	{
		case 'cse':
			deptId = 1;break;
		case 'ece':
			deptId = 2;break;
		case 'mech':
			deptId = 3;break;
		case 'eee':
			deptId = 4;break;
		case 'civil':
            deptId = 5;break;
        case 'ecep':
            deptId = 6;break;
	}
	return deptId;
}

//routes
app.use('/', require('./routes/index'));

app.use('/users', require('./routes/users'));

app.get("/paper/:filename", (req, res) =>{
    //console.log("Paper route");
    //console.log(path.join(__dirname + '/views/paper' + "/" + req.params.filename.split('.ejs')[0]));

    
    var p_name = req.params.filename.split('.ejs')[0];
    //console.log(p_name);

    var p_id = getId(p_name);
    //console.log(p_id);
    if(req.isAuthenticated())
    {
        User.findOne({'username' : req.user.username, 'paperPresentations.paper': p_id}).count( (err, counts) =>{
            if(err)
            {
                console.log(err);
                req.flash("err_msg","Try again later");
                res.redirect('/paper');
                res.end();
            }
            else if(counts > 0)
            {
                console.log("again");
                res.render(path.join(__dirname + '/views/paper' + "/" + p_name),{reg : true, iLog : true});
            }
            else if(counts == 0)
            {
                console.log("Init");
                res.render(path.join(__dirname + '/views/paper' + "/" + p_name),{reg : false, iLog : true});
            }
        } );
        
    }
    else    res.render(path.join(__dirname + '/views/paper' + "/" + p_name),{reg : false, iLog : false});

});

app.get("/project/:filename", (req, res) =>{
    //console.log("Project route");
    //console.log(path.join(__dirname + '/views/project' + "/" + req.params.filename.split('.ejs')[0]));

    
    var p_name = req.params.filename.split('.ejs')[0];
    //console.log(p_name);

    var p_id = getId(p_name);
    //console.log(p_id);
    if(req.isAuthenticated())
    {
        User.findOne({'username' : req.user.username, 'paperPresentations.paper': p_id}).count( (err, counts) =>{
            if(err)
            {
                console.log(err);
                req.flash("err_msg","Try again later");
                res.redirect('/dashboard');
                res.end();
            }
            else if(counts > 0)
            {
                console.log("again");
                res.render(path.join(__dirname + '/views/project' + "/" + p_name),{reg : true, iLog : true});
            }
            else if(counts == 0)
            {
                console.log("Init");
                res.render(path.join(__dirname + '/views/project' + "/" + p_name),{reg : false, iLog : true});
            }
        } );
        
    }
    else    res.render(path.join(__dirname + '/views/project' + "/" + p_name),{reg : false, iLog : false});

});

app.get("/:folder/:evm/:filename", (req, res) =>{
    //console.log("Requested File is : " +req.params.filename);
    //console.log(path.join(__dirname + '/views/' + req.params.folder + "/" + req.params.filename.split('.ejs')[0]));
    
    if(req.isAuthenticated() && req.params.evm == "event")
    {
        var e_name = req.params.filename.split('.ejs')[0];

        User.findOne({username: req.user.username}, (err, user) => {
            if(err)
            {
                console.log(err);
            }
            else
            {
                var ireg = user.events.some( (event) => {
                    return event.event_name == e_name;
                });
                res.render(path.join(__dirname + '/views/' + req.params.folder + "/" + req.params.filename.split('.ejs')[0]), {reg: ireg, iLog: true});
            }
        });
    }

    else if(req.isAuthenticated() && req.params.evm == "workshop")
    {
        var w_name = req.params.filename.split('.ejs')[0];

        User.findOne({username: req.user.username}, (err, user) => {
            if(err)
            {
                console.log(err);
            }
            else
            {
                var ireg = user.workshops.some( (workshop) => {
                    return ( (workshop.workshop_name == w_name) || (workshop.workshop_name == (w_name + ' 2')));
                });

                if(ireg)
                    console.log("Registered");
                res.render(path.join(__dirname + '/views/' + req.params.folder + "/" + req.params.filename.split('.ejs')[0]), {reg: ireg, iLog: true});
            }
        });
    }
    
    else if(req.params.evm == "workshop" || req.params.evm == "event")
        res.render(path.join(__dirname + '/views/' + req.params.folder + "/" + req.params.filename.split('.ejs')[0]), {reg: false, iLog: false});
    
});


const  PORT = 4444;

//app.listen(PORT, "10.10.157.248",console.log(`Server started on ${PORT}`));
app.listen(4444, () => console.log(' app listening on port 4444!'))
//app.listen(PORT, "YUKTAHA",console.log(`Server started on ${PORT}`));
