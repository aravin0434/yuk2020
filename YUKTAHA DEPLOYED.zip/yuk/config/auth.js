function isLoggedIn(req, res, next){
    if(req.isAuthenticated()){
        return next();
    }
    req.flash("error_msg", 'Please log in first');
    res.redirect("/users/login");
}

function isNotLoggedIn(req, res, next){
    if(!req.isAuthenticated()){
        return next();
    }
    req.flash("error_msg", 'Your are Logged In');
    res.redirect("/users/login");
}
module.exports = {iLog: isLoggedIn, iNLog: isNotLoggedIn};